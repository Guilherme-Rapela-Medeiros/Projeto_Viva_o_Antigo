return {
  board = "arduino:avr:uno",
  port = "/dev/ttyUSB0",
  baudrate = "115200",
}
